//
//  AdvancedNavigationDemoAppApp.swift
//  AdvancedNavigationDemoApp
//
//  Created by Midlaj Mc on 08/05/26.
//

import SwiftUI

@main
struct AdvancedNavigationDemoApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationContainer(router: Router()) {
                HomeView()
            }
        }
    }
}
