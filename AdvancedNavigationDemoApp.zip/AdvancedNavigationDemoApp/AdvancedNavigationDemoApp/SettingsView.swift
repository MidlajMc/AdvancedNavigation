//
//  SettingsView.swift
//  AdvancedNavigationDemoApp
//
//  Created by Midlaj Mc on 08/05/26.
//

import SwiftUI

struct SettingsView: View {

    @Environment(Router.self) private var router

    var body: some View {

        NavigationStack {
            VStack(spacing: 20) {

                Text("Settings Sheet")
                    .font(.title)

                Button("Dismiss") {
                    router.dismissSheet()
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
        }
    }
}
