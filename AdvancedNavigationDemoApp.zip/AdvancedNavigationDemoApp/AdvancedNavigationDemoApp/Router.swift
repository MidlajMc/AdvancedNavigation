//
//  Router.swift
//  AdvancedNavigationDemoApp
//
//  Created by Midlaj Mc on 08/05/26.
//

import SwiftUI

@Observable
final class Router {

    // NavigationStack path
    var navigationStackPath = NavigationPath()

    // Sheet
    var presentingSheet: SheetDestination?

    // Full Screen
    var presentingFullScreen: FullScreenDestination?

    // MARK: - Push

    func push(_ destination: PushDestination) {
        navigationStackPath.append(destination)
    }

    func pop() {
        navigationStackPath.removeLast()
    }

    func popToRoot() {
        navigationStackPath = NavigationPath()
    }

    // MARK: - Sheet

    func presentSheet(_ sheet: SheetDestination) {
        presentingSheet = sheet
    }

    func dismissSheet() {
        presentingSheet = nil
    }

    // MARK: - Full Screen

    func presentFullScreen(_ destination: FullScreenDestination) {
        presentingFullScreen = destination
    }

    func dismissFullScreen() {
        presentingFullScreen = nil
    }

    // MARK: - Deep Link Example

    func handleDeepLink(_ url: URL) {
        if url.absoluteString.contains("profile") {
            push(.profile)
        }
    }
}
