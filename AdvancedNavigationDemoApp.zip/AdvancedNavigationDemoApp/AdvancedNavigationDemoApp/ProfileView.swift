//
//  ProfileView.swift
//  AdvancedNavigationDemoApp
//
//  Created by Midlaj Mc on 08/05/26.
//

import SwiftUI

struct ProfileView: View {

    var body: some View {
        VStack(spacing: 20) {

            Image(systemName: "person.circle.fill")
                .resizable()
                .frame(width: 100, height: 100)

            Text("Profile Screen")
                .font(.title)
        }
        .padding()
    }
}
