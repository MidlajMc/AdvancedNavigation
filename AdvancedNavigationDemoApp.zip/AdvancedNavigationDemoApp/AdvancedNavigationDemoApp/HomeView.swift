//
//  ContentView.swift
//  AdvancedNavigationDemoApp
//
//  Created by Midlaj Mc on 08/05/26.
//

import SwiftUI

struct HomeView: View {

    @Environment(Router.self) private var router

    var body: some View {

        VStack(spacing: 20) {

            Text("Advanced Navigation")
                .font(.largeTitle.bold())

            Button("Push Detail Screen") {
                router.push(.detail("SwiftUI Navigation"))
            }
            .buttonStyle(.borderedProminent)

            Button("Push Profile Screen") {
                router.push(.profile)
            }
            .buttonStyle(.bordered)

            Button("Present Sheet") {
                router.presentSheet(.settings)
            }
            .buttonStyle(.bordered)

            Button("Present Full Screen") {
                router.presentFullScreen(.fullScreen)
            }
            .buttonStyle(.bordered)
        }
        .padding()
    }
}
