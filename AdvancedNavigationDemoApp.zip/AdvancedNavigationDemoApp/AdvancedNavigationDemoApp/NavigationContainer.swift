//
//  NavigationContainer.swift
//  AdvancedNavigationDemoApp
//
//  Created by Midlaj Mc on 08/05/26.
//

import SwiftUI

struct NavigationContainer<Content: View>: View {
    
    @State var router: Router
    
    @ViewBuilder var content: () -> Content
    
    var body: some View {
        
        NavigationStack(path: $router.navigationStackPath) {
            content()
                .navigationDestination(for: PushDestination.self) { destination in
                    view(for: destination)
                }
        }
        .sheet(item: $router.presentingSheet) { sheet in
            sheetView(for: sheet)
        }
        .fullScreenCover(item: $router.presentingFullScreen) { fullScreen in
            fullScreenView(for: fullScreen)
        }
        .environment(router)
        .onOpenURL { url in
            router.handleDeepLink(url)
        }
    }
    
    // MARK: - Push Navigation
    @ViewBuilder
    private func view(for destination: PushDestination) -> some View {
        
        switch destination {
        case .detail(let title):
            DetailView(title: title)
            
        case .profile:
            ProfileView()
        }
    }
    
    // MARK: - Sheet Navigation
    @ViewBuilder
    private func sheetView(for destination: SheetDestination) -> some View {
        
        switch destination {
        case .settings:
            SettingsView()
        }
    }
    
    // MARK: - Full Screen Navigation
    
    @ViewBuilder
    private func fullScreenView(for destination: FullScreenDestination) -> some View {
        
        switch destination {
        case .fullScreen:
            FullScreenView()
        }
    }
}
