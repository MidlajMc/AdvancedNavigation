//
//  DetailView.swift
//  AdvancedNavigationDemoApp
//
//  Created by Midlaj Mc on 08/05/26.
//

import SwiftUI

struct DetailView: View {

    let title: String

    @Environment(Router.self) private var router

    var body: some View {

        VStack(spacing: 20) {

            Text(title)
                .font(.largeTitle)

            Button("Go Back") {
                router.pop()
            }
            .buttonStyle(.borderedProminent)

            Button("Back To Root") {
                router.popToRoot()
            }
            .buttonStyle(.bordered)
        }
        .padding()
    }
}
