//
//  Destination.swift
//  AdvancedNavigationDemoApp
//
//  Created by Midlaj Mc on 08/05/26.
//

import SwiftUI

// Push Destinations

enum PushDestination: Hashable {
    case detail(String)
    case profile
}

// Sheet Destinations

enum SheetDestination: Identifiable {
    case settings

    var id: String {
        switch self {
        case .settings:
            return "settings"
        }
    }
}

// Full Screen Destinations

enum FullScreenDestination: Identifiable {
    case fullScreen

    var id: String {
        switch self {
        case .fullScreen:
            return "fullScreen"
        }
    }
}
