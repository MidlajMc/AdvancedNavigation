//
//  FullScreenView.swift
//  AdvancedNavigationDemoApp
//
//  Created by Midlaj Mc on 08/05/26.
//

import SwiftUI

struct FullScreenView: View {

    @Environment(Router.self) private var router

    var body: some View {

        ZStack {
            Color.black
                .ignoresSafeArea()

            VStack(spacing: 20) {

                Text("Full Screen View")
                    .foregroundStyle(.white)
                    .font(.largeTitle)

                Button("Close") {
                    router.dismissFullScreen()
                }
                .buttonStyle(.borderedProminent)
            }
        }
    }
}
